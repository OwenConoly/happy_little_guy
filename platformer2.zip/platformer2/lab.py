#!/usr/bin/env python3

##################
# Game Constants #
##################

# other than TILE_SIZE, feel free to move, modify, or delete these constants as
# you see fit.

TILE_SIZE = 128

# vertical movement
GRAVITY = -9
MAX_DOWNWARD_SPEED = 48
PLAYER_JUMP_SPEED = 62
PLAYER_JUMP_DURATION = 3
PLAYER_BORED_THRESHOLD = 60

# horizontal movement
PLAYER_DRAG = 6
PLAYER_MAX_HORIZONTAL_SPEED = 48
PLAYER_HORIZONTAL_ACCELERATION = 16

# new stuff
STORM_LIGHTNING_ROUNDS = 5
STORM_RAIN_ROUNDS = 10

BEE_SPEED = 40
CATERPILLAR_SPEED = 16
PEANUT_SPEED = 60

CHIPMUNK_POWER = 5


# the following maps single-letter strings to the name of the object they
# represent, for use with deserialization in Game.__init__.
SPRITE_MAP = {
    "p": "player",
    "c": "cloud",
    "=": "floor",
    "B": "building",
    "C": "castle",
    "u": "cactus",
    "t": "tree",
    "f": "fire",
    "s": "storm",
    "e": "bee",
    "~": "caterpillar",
    "h": "helicopter",
    "w": "water",
    "i": "chipmunk"
}


TEXTURE_MAP = {
    "building": "classical_building",
    "cactus": "cactus",
    "castle": "castle",
    "cloud": "cloud",
    "floor": "black_large_square",
    "tree": "tree",
    "fire": "fire",
    "bee": "bee",
    "caterpillar": "caterpillar",
    "helicopter": "helicopter",
    "water": "water_wave",
    "chipmunk": "chipmunk",
    "peanut": "peanuts"
}

PLAYER_TEXTURE_MAP = {
    "normal": "slight_smile",
    "idle": "sleeping",
    "defeat": "injured",
    "victory": "partying_face"
}


GRAVITY_SPRITES = ("player")


##########################
# Classes and Game Logic #
##########################


class Sprite:
    def __init__(self, name, x, y):
        self.name = name
        self.x = x
        self.y = y
        self.dead = False

    def get_texture(self):
        return TEXTURE_MAP[self.name]

    def timestep(self, keys):
        pass

    def getrectangle(self):
        return Rectangle(self.x, self.y, TILE_SIZE, TILE_SIZE)


class DynamicSprite(Sprite):
    def __init__(self, name, x, y, vx = 0, vy = 0):
        Sprite.__init__(self, name, x, y)
        self.vx = vx
        self.vy = vy

    def timestep(self, keys):
        self.x += self.vx
        self.y += self.vy

    def move(self, vector):
        if vector:
            self.x += vector[0]
            self.y += vector[1]

    def translation_vector(self, other, only_y):
        movement = Rectangle.translation_vector(other.getrectangle(), self.getrectangle())
        return movement if movement and (movement[1] or not only_y) else None

    def handle_collision(self, other, only_y):
        if isinstance(other, DynamicSprite) or self.dead or other.dead:
            return
        movement = self.translation_vector(other, only_y)
        self.move(movement)
        return movement


class Chipmunk(DynamicSprite):
    def timestep(self, keys):
        self.vy += GRAVITY
        self.vy = max(self.vy, -MAX_DOWNWARD_SPEED)
        DynamicSprite.timestep(self, keys)
        

class Player(DynamicSprite):
    def __init__(self, name, x, y):
        DynamicSprite.__init__(self, name, x, y)
        self.boredness = 0
        self.status = "ongoing"
        self.can_jump = True
        self.heli = False
        self.boat = False
        self.jump_remaining = 0
        self.peanuts = 0

    def get_texture(self):
        if self.status == 'defeat':
            return "injured"
        if self.status == 'victory':
            return 'partying_face'
        if self.boat:
            return "passenger_ship"
        if self.heli:
            return "helicopter"
        if self.status == 'ongoing':
            if self.boredness <= PLAYER_BORED_THRESHOLD:
                return 'slight_smile'
            else:
                return 'sleeping'

    def handle_collision(self, other, only_y):
        if other.dead or isinstance(other, Peanut):
            return
        movement = Rectangle.translation_vector(other.getrectangle(), self.getrectangle())
        if movement:
            if isinstance(other, Fire) or isinstance(other, Bee):
                self.status = "defeat"
                return # idk, we're not supposed to collide with the fire apparently

            if isinstance(other, Caterpillar):
                if movement[1] > 0:
                    other.dead = True
                else:
                    self.status = "defeat"
                return

            if movement[1] > 0:
                self.can_jump = True

            if other.name == 'castle':
                self.status = "victory"
            elif other.name == 'cactus':
                self.status = "defeat"
            elif isinstance(other, Storm) and other.get_texture() == "thunderstorm":
                self.status = "defeat"
            elif other.name == "helicopter":
                self.heli = True
                other.dead = True
            elif other.name == "water":
                self.boat = True
            elif other.name == "chipmunk":
                self.peanuts = CHIPMUNK_POWER
                other.dead = True
                return
                        
            if movement and (movement[1] or not only_y):
                self.move(movement)
                if movement[0] * self.vx < 0:
                    self.vx = 0
                if movement[1] * self.vy < 0:
                    self.vy = 0

            
        return movement

    
    def timestep(self, keys):
        new_sprites = []

        self.boat = False
        self.boredness = 0 if keys else self.boredness + 1

        ax, ay = 0, 0
        ay += GRAVITY

        if 'left' in keys:
            ax -= PLAYER_HORIZONTAL_ACCELERATION
        if 'right' in keys:
            ax += PLAYER_HORIZONTAL_ACCELERATION
        if 'up' in keys and (self.can_jump or self.heli):
            self.jump_remaining = PLAYER_JUMP_DURATION
            self.can_jump = False
        if 'x' in keys and self.peanuts > 0:
            new_sprites += [Peanut("peanut", self.x, self.y, PEANUT_SPEED, 0)]
            self.peanuts -= 1
        if 'z' in keys and self.peanuts > 0:
            new_sprites += [Peanut("peanut", self.x, self.y, -PEANUT_SPEED, 0)]
            self.peanuts -= 1

        if self.jump_remaining > 0:
            self.vy = PLAYER_JUMP_SPEED
            self.jump_remaining -= 1
        
        self.vx += ax
        self.vy += ay
        self.vy = max(self.vy, -MAX_DOWNWARD_SPEED)

        # recompute velocities to take drag into account
        dragx = min(PLAYER_DRAG, self.vx) if self.vx > 0 else max(-PLAYER_DRAG, self.vx) if self.vx < 0 else 0
        self.vx -= dragx

        # cap horizontal velocity
        self.vx = max(-PLAYER_MAX_HORIZONTAL_SPEED, self.vx)
        self.vx = min(PLAYER_MAX_HORIZONTAL_SPEED, self.vx)

        self.x += self.vx
        self.y += self.vy 

        if self.y < -TILE_SIZE:
            self.status = "defeat"

        for sprite in new_sprites:
            sprite.timestep(keys)
        return new_sprites


class Fire(DynamicSprite):
    def timestep(self, keys):
        self.vy += GRAVITY
        self.vy = max(self.vy, -MAX_DOWNWARD_SPEED)
        self.y += self.vy

    def handle_collision(self, other, only_y):
        if isinstance(other, Caterpillar):
            return Caterpillar.handle_collision(other, self, only_y)
        if super().handle_collision(other, only_y):
            self.vx = 0
            self.vy = 0


class Peanut(DynamicSprite):
    def handle_collision(self, other, only_y):
        if not other.dead and not self.dead:
            movement = self.translation_vector(other, only_y)
            if movement:
                if not isinstance(other, DynamicSprite) or isinstance(other, Caterpillar):
                    self.dead = True
                if other.name in ("caterpillar", "cactus", "tree"):
                    self.dead = True
                    other.dead = True


class Storm(Sprite):
    def __init__(self, name, x, y):
        super().__init__(name, x, y)
        self.steps = 0
    
    def timestep(self, keys):
        self.steps += 1
        self.steps %= (STORM_LIGHTNING_ROUNDS + STORM_RAIN_ROUNDS)

    def get_texture(self):
        return "thunderstorm" if self.steps < STORM_LIGHTNING_ROUNDS else "rainy"
    

class Bee(DynamicSprite):
    def __init__(self, name, x, y):
        super().__init__(name, x, y)
        self.vy = BEE_SPEED

    def handle_collision(self, other, only_y):
        if super().handle_collision(other, only_y):
            self.vy = -self.vy

            
class Caterpillar(DynamicSprite):
    def __init__(self, name, x, y):
        super().__init__(name, x, y)
        self.vx = CATERPILLAR_SPEED

    def timestep(self, keys):
        self.vy += GRAVITY
        self.vy = max(self.vy, -MAX_DOWNWARD_SPEED)
        super().timestep(keys)

    def handle_collision(self, other, only_y):
        if isinstance(other, Player) or isinstance(other, Peanut):
            return other.handle_collision(self, only_y)
        if self.dead or other.dead:
            return
        movement = DynamicSprite.translation_vector(self, other, only_y)
        if movement:
            if isinstance(other, Fire):
                self.dead = True
                return
            if movement[0]:
                self.vx = -self.vx
            if movement[1]:
                self.vy = 0
        self.move(movement)


class Rectangle:
    """
    A rectangle object to help with collision detection and resolution.
    """

    def __init__(self, x, y, w, h):
        """
        Initialize a new rectangle.

        `x` and `y` are the coordinates of the bottom-left corner. `w` and `h`
        are the dimensions of the rectangle.
        """
        self.x = x
        self.y = y
        self.w = w
        self.h = h

    def intersects(self, other):
        """
        Check whether `self` and `other` (another Rectangle) overlap.

        Rectangles are open on the top and right sides, and closed on the
        bottom and left sides; concretely, this means that the rectangle
        [0, 0, 1, 1] does not intersect either of [0, 1, 1, 1] or [1, 0, 1, 1].
        """
        return (self.x - other.w < other.x < self.x + self.w) and (self.y - other.h < other.y < self.y + self.h)

    @staticmethod
    def translation_vector(r1, r2):
        """
        Compute how much `r2` needs to move to stop intersecting `r1`.

        If `r2` does not intersect `r1`, return `None`.  Otherwise, return a
        minimal pair `(x, y)` such that translating `r2` by `(x, y)` would
        suppress the overlap. `(x, y)` is minimal in the sense of the "L1"
        distance; in other words, the sum of `abs(x)` and `abs(y)` should be
        as small as possible.

        When two pairs `(x1, y1)` and `(x2, y2)` are tied in terms of this
        metric, return the one whose first element has the smallest
        magnitude.
        """
        if r1.intersects(r2):
            move_up = (0, r1.y + r1.h - r2.y)
            move_down = (0, r1.y - r2.h - r2.y)
            move_right = (r1.x + r1.w - r2.x, 0)
            move_left = (r1.x - r2.w - r2.x, 0)
            return min((move_up, move_down, move_right, move_left), key=lambda x: abs(x[0]) + abs(x[1]) + 0.001 * abs(x[0]))
        return None


class Game:
    def __init__(self, level_map):
        """
        Initialize a new game, populated with objects from `level_map`.

        `level_map` is a 2D array of 1-character strings; all possible strings
        (and some others) are listed in the SPRITE_MAP dictionary.  Each
        character in `level_map` corresponds to a sprite of size `TILE_SIZE *
        TILE_SIZE`.

        This function is free to store `level_map`'s data however it wants.
        For example, it may choose to just keep a copy of `level_map`; or it
        could choose to read through `level_map` and extract the position of
        each sprite listed in `level_map`.

        Any choice is acceptable, as long as it works with the implementation
        of `timestep` and `render` below.
        """
        static_map = {"storm": Storm}
        dynamic_map = {"fire": Fire, "bee": Bee, "caterpillar": Caterpillar, "chipmunk": Chipmunk}
        self.dynamics = []
        self.statics = []
        for i in range(len(level_map)):
            for j in range(len(level_map[i])):
                if level_map[i][j] != " ":
                    name = SPRITE_MAP[level_map[i][j]]
                    x = j * TILE_SIZE
                    y = (len(level_map) - 1 - i) * TILE_SIZE
                    if name == 'player':
                        self.player = Player(name, x, y)
                        self.dynamics += [self.player]
                    elif name in dynamic_map:
                        self.dynamics += [dynamic_map[name](name, x, y)]
                    elif name in static_map:
                        self.statics += [static_map[name](name, x, y)]
                    else:
                        self.statics += [Sprite(name, x, y)]
        
        self.static_buckets = self.get_buckets(True)

    def get_buckets(self, static=False):
        sprite_buckets = {}
        for sprite in (self.statics if static else self.dynamics):
            loc = (sprite.x // TILE_SIZE, sprite.y // TILE_SIZE)
            sprite_buckets.setdefault(loc, []).append(sprite)
        return sprite_buckets

    def get_close_sprites(x, y, buckets):
        bucket_x, bucket_y = x // TILE_SIZE, y // TILE_SIZE
        for other_x in range(bucket_x - 1, bucket_x + 2):
            for other_y in range(bucket_y - 1, bucket_y + 2):
                yield from buckets.get((other_x, other_y), [])

    def timestep(self, keys):
        """
        Simulate the evolution of the game state over one time step.  `keys` is
        a list of currently pressed keys.
        """
        if self.player.status != "ongoing":
            return
        
        for sprite in self.statics + self.dynamics:
            self.dynamics += sprite.timestep(keys) or []
        
        dynamic_buckets = self.get_buckets()
                
        for only_y in (True, False):
            for statics in (True, False):
                for sprite1 in self.dynamics:
                    for sprite2 in Game.get_close_sprites(sprite1.x, sprite1.y, self.static_buckets if statics else dynamic_buckets):
                        if sprite1 != sprite2:
                            sprite1.handle_collision(sprite2, only_y)
                
    def render(self, w, h):
        """
        Report status and list of sprite dictionaries for sprites with a
        horizontal distance of w//2 from player.  See writeup for details.
        """
        out = []
        px = self.player.x
        for sprite in (self.statics + self.dynamics):
            if not sprite.dead:
                if px - w//2 - TILE_SIZE < sprite.x < px + w//2 and -TILE_SIZE < sprite.y < h:
                    out += [{'texture': sprite.get_texture(), 
                            'pos': (sprite.x, sprite.y), 
                            'player': isinstance(sprite, Player)}]
        return (self.player.status, out)


if __name__ == "__main__":
    pass
